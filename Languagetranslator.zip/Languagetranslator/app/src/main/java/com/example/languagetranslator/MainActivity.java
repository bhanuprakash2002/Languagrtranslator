package com.example.languagetranslator;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.nl.translate.*;
import java.util.*;
import com.google.mlkit.common.model.DownloadConditions;

public class MainActivity extends AppCompatActivity {

    Spinner sourceLangSpinner, targetLangSpinner;
    EditText inputText;
    Button speakButton, translateButton, readButton;
    TextView translatedText;

    TextToSpeech tts;
    Map<String, String> languageMap;

    final int VOICE_INPUT_REQ = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sourceLangSpinner = findViewById(R.id.sourceLangSpinner);
        targetLangSpinner = findViewById(R.id.targetLangSpinner);
        inputText = findViewById(R.id.inputText);
        speakButton = findViewById(R.id.speakButton);
        translateButton = findViewById(R.id.translateButton);
        translatedText = findViewById(R.id.translatedText);
        readButton = findViewById(R.id.readButton);
        readButton.setEnabled(false); // Initially disabled

        setupLanguageMap();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<>(languageMap.keySet()));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sourceLangSpinner.setAdapter(adapter);
        targetLangSpinner.setAdapter(adapter);
        sourceLangSpinner.setSelection(adapter.getPosition("English"));
        targetLangSpinner.setSelection(adapter.getPosition("Hindi"));

        tts = new TextToSpeech(this, status -> {});

        speakButton.setOnClickListener(v -> startVoiceInput());

        translateButton.setOnClickListener(v -> {
            String sourceLang = languageMap.get(sourceLangSpinner.getSelectedItem().toString());
            String targetLang = languageMap.get(targetLangSpinner.getSelectedItem().toString());
            String text = inputText.getText().toString().trim();

            if (!text.isEmpty()) {
                translateText(sourceLang, targetLang, text);
            } else {
                Toast.makeText(this, "Please enter or speak text to translate.", Toast.LENGTH_SHORT).show();
            }
        });

        readButton.setOnClickListener(v -> {
            String text = translatedText.getText().toString();
            if (!text.isEmpty()) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            }
        });
    }

    void startVoiceInput() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...");
        try {
            startActivityForResult(i, VOICE_INPUT_REQ);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input failed", Toast.LENGTH_SHORT).show();
            Log.e("VoiceInput", "Error starting voice input", e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_INPUT_REQ && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && result.size() > 0) {
                inputText.setText(result.get(0));
            }
        }
    }

    void translateText(String sourceLangCode, String targetLangCode, String text) {
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.fromLanguageTag(sourceLangCode))
                .setTargetLanguage(TranslateLanguage.fromLanguageTag(targetLangCode))
                .build();

        Translator translator = Translation.getClient(options);

        // Allow download over any network (Wi-Fi or Mobile)
        DownloadConditions conditions = new DownloadConditions.Builder().build();

        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(unused -> {
                    translator.translate(text)
                            .addOnSuccessListener(translated -> {
                                translatedText.setText(translated);
                                readButton.setEnabled(true); // Enable Read button
                            })
                            .addOnFailureListener(e -> {
                                String err = "Translation failed: " + e.getMessage();
                                translatedText.setText(err);
                                Log.e("Translation", err, e);
                            });
                })
                .addOnFailureListener(e -> {
                    String err = "Model download failed: " + e.getMessage();
                    translatedText.setText(err);
                    Log.e("ModelDownload", err, e);
                });
    }

    void setupLanguageMap() {
        languageMap = new HashMap<>();
        languageMap.put("English", "en");
        languageMap.put("Hindi", "hi");
        languageMap.put("Telugu", "te");
        languageMap.put("Tamil", "ta");
        languageMap.put("Kannada", "kn");
        languageMap.put("Bengali", "bn");
        languageMap.put("Gujarati", "gu");
        languageMap.put("Marathi", "mr");
        languageMap.put("Malayalam", "ml");
        languageMap.put("Urdu", "ur");
        languageMap.put("French", "fr");
        languageMap.put("German", "de");
        languageMap.put("Spanish", "es");
        languageMap.put("Chinese", "zh");
        languageMap.put("Japanese", "ja");
        languageMap.put("Korean", "ko");
        languageMap.put("Russian", "ru");
        // Add more supported languages if needed
    }
}
